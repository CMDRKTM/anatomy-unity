using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollScript : MonoBehaviour
{
    private bool isDragging = false;
    private Vector3 initialMousePosition;
    private Vector3 initialObjectPosition;

    // Define the y-coordinate range
    private float minY = -0.174f;
    private float maxY = 0.16f;

    private void Start()
    {
        // Start the GameObject at the minimum y position
        transform.localPosition = new Vector3(transform.localPosition.x, minY, transform.localPosition.z);
    }

    void Update()
    {
        // Check for mouse input
        if (Input.GetMouseButtonDown(0))
        {
            // Start dragging
            isDragging = true;
            initialMousePosition = Input.mousePosition;
            initialObjectPosition = transform.localPosition;
        }
        else if (Input.GetMouseButtonUp(0))
        {
            // Stop dragging
            isDragging = false;
        }

        if (isDragging)
        {
            // Calculate the mouse movement
            Vector3 currentMousePosition = Input.mousePosition;
            float mouseDeltaY = (currentMousePosition.y - initialMousePosition.y) / Screen.height;

            // Calculate the new position
            float newY = initialObjectPosition.y + mouseDeltaY;

            // Clamp the y position to stay within the specified range
            newY = Mathf.Clamp(newY, minY, maxY);

            // Smoothly move the object to the new position
            transform.localPosition = new Vector3(transform.localPosition.x, Mathf.Lerp(transform.localPosition.y, newY, 0.1f), transform.localPosition.z);
        }
    }
}
