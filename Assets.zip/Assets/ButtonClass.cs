using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonClass : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    public string functionName;
    public string parameterValue; // New variable to hold the parameter value
    public bool showGrey = true;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void OnMouseDown()
    {
        if (showGrey)
        {
            spriteRenderer.color = Color.grey;

        }
    }

    void OnMouseUp()
    {
        if (showGrey)
        {
            spriteRenderer.color = Color.white;

        }

        GameObject gameManager = GameObject.Find("GameManager");
        if (gameManager != null)
        {
            if (!string.IsNullOrEmpty(parameterValue))
            {
                gameManager.SendMessage(functionName, parameterValue);
            }
            else
            {
                gameManager.SendMessage(functionName);
            }
        }
        else
        {
            Debug.LogWarning("GameManager not found!");
        }
    }
}
