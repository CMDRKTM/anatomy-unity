using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartGame : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    public bool showGrey = true;
    public GameObject textBoxObject;
    private Color initialColor;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void OnMouseDown()
    {
        if (showGrey)
        {
            initialColor = spriteRenderer.color;

            spriteRenderer.color = Color.grey;

        }
    }

    void OnMouseUp()
    {
        if (showGrey)
        {
            spriteRenderer.color = Color.white;

        }

        textBoxObject.SetActive(true);
        Destroy(gameObject);
    }
}
