using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public Animator rateAnimator;
    public float rateFloat;
    public GameObject[] translatedTexts;
    public GameObject[] sectionObjects;
    public SpriteRenderer heartRenderer;
    public GameObject restartBox;
    public GameObject overlayObject;
    public string[] translatedStrings;
    public string[] randomCharacters;
    public GameObject organObject;
    public Sprite[] spriteList;

    public GameObject[] instructionsList;
    public GameObject[] disableList;

    private bool isTranslated;
    private int heartBeat;
    public int initialHeartBeat = 60;

    private AudioSource AS;
    public TextMeshPro heartPro;
    public GameObject textBox;
    private bool isDead = false;
    public AudioClip normalAudio;
    public AudioClip dangerAudio;
    public AudioClip deadAudio;
    public GameObject bloodObject;
    private float increaseInterval = 0.66f; // Timer to track the elapsed time for BPM increment

    private float heartBeatTimer = 0f; // Timer to track the elapsed time for heartBeat decrement
    private float heartBeatInterval = 0f; // Interval between heartbeats
    private float bpmIncrementTimer = 0f; // Timer to track the elapsed time for BPM increment
    private float countdownTimer = 0f; // Timer for countdown
    public bool isTubeRight = false;
    public bool isTubeFirst = false;
    public TextMeshPro countDownText;
    private int countDownInt = 120;
    public GameObject progressObject;
    private int deadBeat = 180;

    private Dictionary<string, string> translationDict = new Dictionary<string, string>
    {
        {"xionggu", "�ع�"},
        {"leigu", "�߹�"},
        {"shangqiang", "��ǻ����"},
        {"youfeidong", "�ҷζ���"},
        {"youfeijing", "�ҷξ���"},
        {"xiaqiang", "��ǻ����"},
        {"zhudongmai", "������"},
        {"zuofeidong", "��ζ���"},
        {"zuofeijing", "��ξ���"},
        {"sanjianban", "�����"},
        {"feidongmaiban", "�ζ�����"},
        {"zhudongmaiban", "��������"},
        {"erjianban", "�����"},
        {"funeixieji","����б��" },
                {"fuwaixieji","����б��" },
                                {"fuzhiji","��ֱ��" },

                                                                {"fuhengji","���ἡ" },
                                                                {"zhichang","ֱ��" },
                                                                {"huichang","�س�" },
                                                                {"kongchang","�ճ�" },
                                                                                                                                {"mangchang","ä��" },

    };

    void Start()
    {
        heartBeat = initialHeartBeat;
        AS = GetComponent<AudioSource>();
        UpdateCountdownText(); // Initialize the countdown text
    }

    void Update()
    {
        heartPro.text = heartBeat.ToString();
        rateAnimator.SetFloat("AnimSpeed", rateFloat);

        // Calculate rateFloat based on heartBeat
        rateFloat = 4.167f / (60f / (float)heartBeat);
        heartBeatInterval = 60f / (float)heartBeat; // Calculate interval in seconds based on bpm

        // Update heartBeatTimer
        heartBeatTimer += Time.deltaTime;
        if (heartBeatTimer >= heartBeatInterval && heartBeat > 0)
        {
            AS.Play(); // Play the heartbeat sound
            heartBeatTimer = 0f; // Reset the timer
        }

        // Update bpmIncrementTimer
        bpmIncrementTimer += Time.deltaTime;
        if (bpmIncrementTimer >= increaseInterval)
        {
            heartBeat += 1; // Increment BPM by 1
            bpmIncrementTimer = 0f; // Reset the timer
            UpdateCountdownText(); // Update the countdown text with the transformed value
        }

        // Check if heartBeat has reached the deadBeat
        if (heartBeat >= deadBeat)
        {
            rateAnimator.Play("deadanim");
            heartBeat = 0;
            AS.clip = deadAudio;
            increaseInterval = float.PositiveInfinity;

            AS.Play();
            AS.loop = true;
            isDead = true;
            bloodObject.SetActive(true);
            Invoke("StartRestart", 2f);
        }
    }

    void StartRestart()
    {
        restartBox.SetActive(true);
    }
    private void UpdateCountdownText()
    {
        // Calculate remaining time until deadBeat based on current increaseInterval
        float remainingBeats = deadBeat - heartBeat;
        float remainingTime = remainingBeats * increaseInterval;

        // Convert remaining time to minutes and seconds
        int minutes = Mathf.FloorToInt(remainingTime / 60f);
        int seconds = Mathf.FloorToInt(remainingTime % 60f);
        countDownText.text = string.Format("{0}:{1:00}", minutes, seconds);

        // Normalize the heart rate progress between 0 and 1
        float normalizedProgress = (float)(heartBeat - initialHeartBeat) / (deadBeat - initialHeartBeat);

        // Update progress bar scale
        float progressBarMaxScale = 1.815f; // Maximum scale value for the progress bar
        float progress = normalizedProgress * progressBarMaxScale;
        progressObject.transform.localScale = new Vector3(progress, 0.7371615f, 0.7371615f);
    }


    public void Translate()
    {
        if (!isTranslated)
        {
            isTranslated = true;
            for (int i = 0; i < translatedTexts.Length; i++)
            {
                if (translatedTexts[i].transform.parent.gameObject.transform.parent.gameObject.activeSelf)
                {
                    if (disableList[i])
                    {
                        disableList[i].SetActive(false);
                    }
                    StartCoroutine(TranslateText(translatedTexts[i], translatedStrings[i]));
                    translatedTexts[i].SetActive(true);
                }
            }
        }
    }

    private IEnumerator TranslateText(GameObject textObject, string finalText)
    {
        if(isDead == false)
        {
            Transform child = textObject.transform.GetChild(0);
            TextMeshPro tmpro = child.GetComponent<TextMeshPro>();
            int length = finalText.Length;
            float duration = 1f;
            float interval = 1f / 20f;
            float elapsedTime = 0f;

            while (elapsedTime < duration)
            {
                tmpro.text = GenerateRandomString(length);
                elapsedTime += interval;
                yield return new WaitForSeconds(interval);
            }

            tmpro.text = finalText;
            textObject.GetComponent<SpriteRenderer>().color = Color.white;
        }

    }

    private string GenerateRandomString(int length)
    {
        string randomString = "";
        for (int i = 0; i < length; i++)
        {
            randomString += randomCharacters[Random.Range(0, randomCharacters.Length)];
        }
        return randomString;
    }

    public void Select(string partString)
    {
        if(isDead == false)
        {
            for (int i = 0; i < sectionObjects.Length; i++)
            {
                if (sectionObjects[i].activeSelf)
                {
                    Transform instructions = sectionObjects[i].transform.Find("Instructions");
                    Transform instructionsSelected = sectionObjects[i].transform.Find("Instructions Selected");
                    if (instructions != null && instructionsSelected != null)
                    {
                        instructions.gameObject.SetActive(false);
                        instructionsSelected.gameObject.SetActive(true);

                        Transform nameTransform = instructionsSelected.Find("Name");
                        if (nameTransform != null)
                        {
                            TextMeshPro nameText = nameTransform.GetChild(0).GetComponent<TextMeshPro>();
                            if (nameText != null && translationDict.ContainsKey(partString))
                            {
                                nameText.text = translationDict[partString];

                                instructionsSelected.transform.Find("Yes Button").gameObject.GetComponent<ButtonClass>().parameterValue = partString;

                                // Update sprite based on the index in translationDict
                                int index = new List<string>(translationDict.Keys).IndexOf(partString);
                                Debug.Log("Sprite index: " + index.ToString());
                                if (index >= 0 && index < spriteList.Length)
                                {
                                    organObject.GetComponent<SpriteRenderer>().sprite = spriteList[index];
                                }
                            }
                        }
                    }
                    organObject.GetComponent<SpriteRenderer>().enabled = true;

                    break;
                }
            }
        }
      
    }


    void TextBox(string textString)
    {
        GameObject currentTextBox = Instantiate(textBox, new Vector3(0f, 0f, 0f), Quaternion.identity);
        currentTextBox.transform.GetChild(0).GetComponent<TextBox>().textList[0] = textString;
    }

    public void Yes(string partString)
    {
        if (isDead == false)
        {
            No();
            if (partString == "xionggu")
            {
                NextSection();
            }
            else if (partString == "leigu")
            {
                TextBox("�����������⵶��û�е������࣬��ֻ���ٴγ��ԡ�");
                // Disable the SpriteRenderer of the organObject
                organObject.GetComponent<SpriteRenderer>().enabled = false;
                Danger();
            }

            else if (partString == "fuzhiji")
            {
                NextSection();
            }
            else if (partString == "mangchang")
            {
                SceneManager.LoadScene("text1");
            }
            else if (partString == "huichang" | partString == "kongchang" | partString == "zhichang")
            {
                TextBox("�����۵ô�У�������ô���Զ��޼�����");

                organObject.GetComponent<SpriteRenderer>().enabled = false;
                Death();
            }
            else if (partString == "fuhengji" | partString == "fuwaixieji" | partString == "funeixieji")
            {
                TextBox("�⵶��û�б�¶��ȷ�����࣬����������ڼ��ٶ�");
                // Disable the SpriteRenderer of the organObject
                organObject.GetComponent<SpriteRenderer>().enabled = false;
                Danger();
            }
            else if (partString == "sanjianban" | partString == "feidongmaiban" | partString == "zhudongmaiban")
            {
                TextBox("�㷢�ָð�Ĥ��û�й��������⣬�����˱��������ʱ��");

                Danger();
            }
            else if (partString == "erjianban")
            {
                Debug.Log("win");
                SceneManager.LoadScene("text2");
            }
            else
            {
                ConnectTube(partString);
                organObject.GetComponent<SpriteRenderer>().enabled = false;
            }
        }
    }

    void ConnectTube(string partString)
    {

        if (isTubeFirst == false)
        {
            TextBox("��������һ���ܵ���׼��������һ��");

        }
        if (partString == "xiaqiang")
        {
            if (isTubeFirst && isTubeRight)
            {
                isTubeRight = true;
            }
            if (isTubeFirst == false)
            {
                isTubeRight = true;
            }
        }
        else if (partString == "zhudongmai")
        {
            if (isTubeFirst && isTubeRight)
            {
                isTubeRight = true;
            }
            if (isTubeFirst == false)
            {
                isTubeRight = true;
            }
        }
        else
        {
            isTubeRight = false;
        }
        if (isTubeRight)
        {
            if (isTubeFirst)
            {
                Debug.Log("Good");
                isTubeFirst = false;
                isTubeRight = false;
                NextSection();

                return;
            }
        }
        else
        {
            if (isTubeFirst)
            {
                Debug.Log("Bad");
                isTubeFirst = false;
                isTubeRight = false;
                TextBox("Ѫ����û��˳����������������񻯣����æ�Ƴ��������ܵ������³���");

                Danger();
                return;
            }
        }

        if (isTubeFirst == false)
        {
            isTubeFirst = true;
        }
    }

    void NextSection()
    {
        bool foundActive = false;

        for (int i = 0; i < sectionObjects.Length; i++)
        {
            if (sectionObjects[i].activeSelf)
            {
                sectionObjects[i].SetActive(false);

                // Activate the next section if it exists
                if (i + 1 < sectionObjects.Length)
                {
                    sectionObjects[i + 1].SetActive(true);
                    Transform newOrganObject = sectionObjects[i + 1].transform.Find("Organ Object");
                    if (newOrganObject != null)
                    {
                        organObject = newOrganObject.gameObject;
                    }
                    foundActive = true;
                }
                break;
            }
        }

        // Reset isTranslated to false
        if (foundActive)
        {
            isTranslated = false;
        }
    }


    public void Restart()
    {
        SceneManager.LoadScene("startScene");
    }
    public void No()
    {
        // Disable the SpriteRenderer of the organObject
        organObject.GetComponent<SpriteRenderer>().enabled = false;

        // Deactivate "Instructions Selected" and activate "Instructions"
        for (int i = 0; i < sectionObjects.Length; i++)
        {
            if (sectionObjects[i].activeSelf)
            {
                Transform instructionsSelected = sectionObjects[i].transform.Find("Instructions Selected");
                Transform instructions = sectionObjects[i].transform.Find("Instructions");

                if (instructionsSelected != null && instructions != null)
                {
                    instructionsSelected.gameObject.SetActive(false);
                    instructions.gameObject.SetActive(true);
                }
                break;
            }
        }
    }

    public void Danger()
    {
        increaseInterval = 0.1f;
        AS.clip = dangerAudio;
        heartRenderer.color = Color.red;
        countDownText.color = Color.red;
        Invoke("StopDanger", 3f);
    }

    public void Death()
    {
        increaseInterval = 0.03f;
        AS.clip = dangerAudio;
        heartRenderer.color = Color.red;
        countDownText.color = Color.red;
    }

    public void StopDanger()
    {
        if (!isDead)
        {
            increaseInterval = 0.6f;
            AS.clip = normalAudio;
            heartRenderer.color = Color.white;
            countDownText.color = Color.white;
        }
    }



    public void RemoveOverlay()
    {
        Destroy(overlayObject);
    }
}
