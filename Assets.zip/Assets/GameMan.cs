using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameMan : MonoBehaviour
{
    public Animator rateAnimator;
    public float rateFloat;
    public GameObject[] translatedTexts;
    public GameObject[] sectionObjects;
    public SpriteRenderer heartRenderer;

    public string[] translatedStrings;
    public string[] randomCharacters;
    public GameObject organObject;
    public Sprite[] spriteList;
    public GameObject[] instructionsList;
    public GameObject[] disableList;

    private bool isTranslated;
    public int heartBeat;
    private AudioSource AS;
    public TextMeshPro heartPro;
    public GameObject textBox;
    private bool isDead = false;
    public AudioClip normalAudio;
    public AudioClip dangerAudio;
    public AudioClip deadAudio;
    public GameObject bloodObject;
    private float increaseInterval = 0.6f; // Timer to track the elapsed time for heartBeat decrement


    private float heartBeatTimer = 0f; // Timer to track the elapsed time for heartBeat decrement
    private float heartBeatInterval = 0f; // Interval between heartbeats
    private float bpmIncrementTimer = 0f; // Timer to track the elapsed time for BPM increment
    private Dictionary<string, string> translationDict
        = new Dictionary<string, string>
        {
            {"xionggu", "�ع�"},

                               

            {"leigu", "�߹�"},
                                    {"shangqiang", "��ǻ����"}

        };



    void Start()
    {
        AS = GetComponent<AudioSource>();
    }

    void Update()
    {
        heartPro.text = heartBeat.ToString();
        rateAnimator.SetFloat("AnimSpeed", rateFloat);

        // Calculate rateFloat based on heartBeat

            rateFloat = 4.167f / (60f / (float)heartBeat);
            heartBeatInterval = 60f / (float)heartBeat; // Calculate interval in seconds based on bpm
        

        // Update heartBeatTimer
        heartBeatTimer += Time.deltaTime;
        if (heartBeatTimer >= heartBeatInterval && heartBeat > 0)
        {
            AS.Play(); // Play the heartbeat sound
            heartBeatTimer = 0f; // Reset the timer
        }

        // Update bpmIncrementTimer
        bpmIncrementTimer += Time.deltaTime;
        if (bpmIncrementTimer >= increaseInterval)
        {
            heartBeat += 1; // Increment BPM by 1
            bpmIncrementTimer = 0f; // Reset the timer
        }

        if (heartBeat == 180)
        {
            rateAnimator.Play("deadanim");
            heartBeat = 0;
            AS.clip = deadAudio;
            increaseInterval = float.PositiveInfinity;

            AS.Play();
            AS.loop = true;
            isDead = true;
            bloodObject.SetActive(true);
        }
    }

    public void Translate()
    {
        if (!isTranslated)
        {
            isTranslated = true;
            for (int i = 0; i < translatedTexts.Length; i++)
            {
               // Debug.Log("text " + i.ToString() + translatedTexts[i].transform.parent.gameObject.transform.parent.gameObject.activeSelf.ToString());

                    if (translatedTexts[i].transform.parent.gameObject.transform.parent.gameObject.activeSelf)
                    {
                    if (disableList[i])
                    {
                        disableList[i].SetActive(false);
                    }
                        StartCoroutine(TranslateText(translatedTexts[i], translatedStrings[i]));
                    translatedTexts[i].SetActive(true);
                    }
                            }
        }
    }


    private IEnumerator TranslateText(GameObject textObject, string finalText)
    {
        Transform child = textObject.transform.GetChild(0);
        TextMeshPro tmpro = child.GetComponent<TextMeshPro>();
        int length = finalText.Length;
        float duration = 1f;
        float interval = 1f / 20f;
        float elapsedTime = 0f;

        while (elapsedTime < duration)
        {
            tmpro.text = GenerateRandomString(length);
            elapsedTime += interval;
            yield return new WaitForSeconds(interval);
        }

        tmpro.text = finalText;
        textObject.GetComponent<SpriteRenderer>().color = Color.white;
    }

    private string GenerateRandomString(int length)
    {
        string randomString = "";
        for (int i = 0; i < length; i++)
        {
            randomString += randomCharacters[Random.Range(0, randomCharacters.Length)];
        }
        return randomString;
    }

    public void Select(string partString)
    {

        //go through the sectionList in sequence and find the first one that is active
        //once found that gameobject, search in its child objects and find one named "Instructions" set unactive, set "Instructions Selected" set active
        //under Instructions Selected find a object named "Name"
        //get its component textmeshpro and set its text to be the result of searching partString in translationDict


        if (partString == "xionggu")
        {
            instructionsList[0].SetActive(false);
            instructionsList[2].SetActive(false);
            instructionsList[1].SetActive(true);
            organObject.GetComponent<SpriteRenderer>().sprite = spriteList[1];
        }
        else if (partString == "leigu")
        {
            instructionsList[0].SetActive(false);
            instructionsList[1].SetActive(false);
            instructionsList[2].SetActive(true);
            organObject.GetComponent<SpriteRenderer>().sprite = spriteList[2];
        }
    }

    public void Yes(string partName)
    {




        if (partName == "xionggu")
        {
            sectionObjects[0].SetActive(false);
            sectionObjects[1].SetActive(true);
            isTranslated = false;
            
        }

        if (partName == "leigu")
        {
            textBox.SetActive(true);
            textBox.GetComponent<TextBox>().textList[0] = "�������ŵ�����������������ٶ񻯡��㷢����һ����û�е������ֻ࣬���ٴγ���";
            instructionsList[0].SetActive(true);
            instructionsList[1].SetActive(false);
            instructionsList[2].SetActive(false);
            Danger();
            organObject.GetComponent<SpriteRenderer>().sprite = spriteList[0];

        }
    }

    public void No(string organName)
    {
        if (organName == "lung")
        {
            instructionsList[0].SetActive(true);
            instructionsList[1].SetActive(false);
            instructionsList[2].SetActive(false);
            organObject.GetComponent<SpriteRenderer>().sprite = spriteList[0];
        }
    }

    public void Danger()
    {
        increaseInterval = 0.1f;
        AS.clip = dangerAudio;
        heartRenderer.color = Color.red;
        Invoke("StopDanger", 3f);
    }


    public void StopDanger()
    {
        if(isDead == false)
        {
            increaseInterval = 0.6f;
            AS.clip = normalAudio;
            heartRenderer.color = Color.white;

        }


    }
}
