using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class TextBox : MonoBehaviour
{
    public TextMeshPro proText;
    public TextMeshPro arrowText;
    public List<string> textList; // List of strings

    private int currentTextIndex = 0;
    private Coroutine typingCoroutine;
    private bool isTyping = false;
    private AudioSource audioSource;
    public AudioClip[] audioClips;
    public GameObject activeObject;

    void Start()
    {






        audioSource = GetComponent<AudioSource>();
        if (arrowText != null)
        {
            StartCoroutine(AnimateArrowOpacity());
        }
        Reinitialize();

    }
    public void Reinitialize()
    {
        if (textList.Count > 0)
        {
            currentTextIndex = 0;
            proText.text = ""; // Clear the text
            typingCoroutine = StartCoroutine(TypeText(textList[currentTextIndex]));
        }
    }


    void Update()
    {
    }

    void OnMouseDown()
    {
        if (isTyping)
        {
            // If text is currently being typed, finish it immediately
            StopCoroutine(typingCoroutine);
            proText.text = textList[currentTextIndex];
            isTyping = false;
        }
        else if (currentTextIndex < textList.Count - 1)
        {
            if (audioClips[currentTextIndex + 1])
            {
                audioSource.PlayOneShot(audioClips[currentTextIndex + 1]);
            }
           
            StartCoroutine(ChangeText());
        }
        else if (currentTextIndex == textList.Count - 1)
        {
            Destroy(gameObject);
            if (SceneManager.GetActiveScene().name == "startScene")
                activeObject.SetActive(true);

            if (SceneManager.GetActiveScene().name == "text1")
                SceneManager.LoadScene("surgery2");

            if (SceneManager.GetActiveScene().name == "text2")
                activeObject.SetActive(true);
        }
    }

    private IEnumerator ChangeText()
    {
        isTyping = true;

        float fadeDuration = 0.1f;
        float startAlpha = proText.alpha;
        for (float t = 0; t < fadeDuration; t += Time.deltaTime)
        {
            proText.alpha = Mathf.Lerp(startAlpha, 0, t / fadeDuration);
            yield return null;
        }
        proText.alpha = 0;

        currentTextIndex++;
        proText.text = textList[currentTextIndex];

        proText.alpha = 1;

        typingCoroutine = StartCoroutine(TypeText(proText.text));

        yield return typingCoroutine; // Wait until typing finishes

        isTyping = false;
    }

    private IEnumerator TypeText(string text)
    {
        proText.text = "";
        isTyping = true;
        foreach (char letter in text.ToCharArray())
        {
            proText.text += letter;
            yield return new WaitForSeconds(1f / 20f);
        }
        isTyping = false;
    }

    private IEnumerator AnimateArrowOpacity()
    {
        while (true)
        {
            float duration = 2f;
            for (float t = 0; t < duration; t += Time.deltaTime)
            {
                float alpha = Mathf.Lerp(1, 0.3f, Mathf.PingPong(t, duration / 2) / (duration / 2));
                arrowText.alpha = alpha;
                yield return null;
            }
        }
    }
}
