using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartGame : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    public bool showGrey = true;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void OnMouseDown()
    {
        if (showGrey)
        {
            spriteRenderer.color = Color.grey;

        }
    }

    void OnMouseUp()
    {
        if (showGrey)
        {
            spriteRenderer.color = Color.white;

        }
        SceneManager.LoadScene("startScene");
    }
}
